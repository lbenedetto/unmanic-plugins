
Uses API to signal jellyfin to scan library for changes
To use, navigate to http://<your jellyfin server>:8096/web/index.html#!/apikeys.html and generate a new API Key 

Jellyfin icon courtesy of the Jellyfin Project, https://github.com/jellyfin/jellyfin-ux.

This work/it's author is separate from and not affiliated with the Jellyfin Project, https://jellyfin.org/.

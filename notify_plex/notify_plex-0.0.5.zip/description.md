
To find your Plex token, follow the instructions found here: 
- https://support.plex.tv/articles/204059436-finding-an-authentication-token-x-plex-token/

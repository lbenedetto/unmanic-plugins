
**<span style="color:#56adda">0.0.9</span>**
- unspecified stream parameters now can only be channels and codec, language must be specified

**<span style="color:#56adda">0.0.8</span>**
- add fix to ignore commentary streams

**<span style="color:#56adda">0.0.7</span>**
- add fix to avoid KeyError when language tag doesn't exist

**<span style="color:#56adda">0.0.6</span>**
- add option to set default audio to new stereo audio channel

**<span style="color:#56adda">0.0.5</span>**
- add option to remove multichannel audio stream

**<span style="color:#56adda">0.0.4</span>**
- fix file scan test audio stream counter

**<span style="color:#56adda">0.0.3</span>**
- add separate loop test for existing 2 channel stereo streams

**<span style="color:#56adda">0.0.2</span>**
- fix file scan test to ignore files that already have a 2 channel, stereo aac stream

**<span style="color:#56adda">0.0.1</span>**
- initial release

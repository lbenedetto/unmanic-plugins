# Video Encoder H265/HEVC - hevc_nvenc

plugin for [Unmanic](https://github.com/Unmanic)

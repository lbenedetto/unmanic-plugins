
**<span style="color:#56adda">0.0.2</span>**
- Added dubug logging when the file is not to be ignored

**<span style="color:#56adda">0.0.1</span>**
- Initial version

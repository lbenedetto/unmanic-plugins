
Files will be inspected with FFprobe to retrieve their video stream width and height.

If the resolution's width or height are **over** the configured limit,
the file will be ignored from all subsequent file tests and prevented from being added to the pending tasks lists.

---

##### Links:

- [Support](https://unmanic.app/discord)
- [Issues/Feature Requests](https://github.com/Josh5/unmanic.plugin.ignore_video_file_over_resolution/issues)
- [Pull Requests](https://github.com/Josh5/unmanic.plugin.ignore_video_file_over_resolution/pulls)

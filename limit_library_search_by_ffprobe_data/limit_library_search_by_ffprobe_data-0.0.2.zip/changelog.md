
**<span style="color:#56adda">0.0.2</span>**
- Refactor plugin to support JSONata queries of the FFprobe data

**<span style="color:#56adda">0.0.1</span>**
- Initial version
